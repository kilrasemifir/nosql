options.plugins.push(
    RevealChalkboard,
    RevealMenu,
);